
public class Weather {
	
	public String CurrentTempurature;
	public String Condition;
	public String MaxTempurature;
	public String MinTempurature;
	public String WeatherLocation;

}
