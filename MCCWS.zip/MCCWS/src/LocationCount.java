import java.util.List;

public class LocationCount{
	public String Cusine;
	public int numOfLocations;
	public List<Place> locations;
}

