import java.util.List;


public class LocationCount{
	public String Cusine;
	public int NumOfLocations;
	public List<Place> Locations;
}

