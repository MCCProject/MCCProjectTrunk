package GooglePlaceAPI;

import com.google.gson.annotations.SerializedName;

public class Location {
	@SerializedName("lat")
	public Double lat;

	@SerializedName("lng")
	public Double lng;
}
