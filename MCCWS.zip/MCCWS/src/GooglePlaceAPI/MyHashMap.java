package GooglePlaceAPI;
import com.google.gson.annotations.SerializedName;

public class MyHashMap {
	  @SerializedName("myHashMap")
	  public GoogleMapper myHashMap;
}
