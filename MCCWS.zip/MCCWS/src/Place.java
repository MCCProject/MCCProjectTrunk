
public class Place {
	public String Name;
	public String Address;
	public String rating;
	public String Cusine;
	public boolean OpenNow;
	public double Distance;
	public String IconURI;
}
